 var express    = require('express'),
  	app        = express();
var watson = require('watson-developer-cloud');
var qs = require('qs');
var vcapServices = require('vcap_services');
var extend = require('util')._extend;
require('./config/express')(app);
var conversation_controller = require('./controllers/conversation-controller');

//Creating the session object
var session = require('client-sessions');

app.use(session({
  cookieName: 'session',
  secret: 'API_KEY_SECRET_AUDIO',
  duration: 30 * 60 * 1000,
  activeDuration: 5 * 60 * 1000,
}));

var authorization = new watson.AuthorizationV1({
  username: '05a19cf0-3a8a-47fe-bf78-e08dd3cb31cd',
  password: '4Nhcu7LDSd1S',
  url: 'https://stream.watsonplatform.net/authorization/api', // Speech tokens
});

//Función para comunicación con el conversation
app.get('/token', function(req, res, next) {
    authorization.getToken({
      url: 'https://stream.watsonplatform.net/text-to-speech/api'
    },
    function (err, token) {
      if (!token) {
        console.log('error:', err);
      } else {
        res.send(token)
      }
    });
});