/**
 * Credenciales de Watson
 */

var watson = require('watson-developer-cloud');
var exports = module.exports = {};
var conversation = watson.conversation({
    "url": "https://gateway.watsonplatform.net/conversation/api",
    "password": "DP24S3iyCH6t",
    "username": "3307cefa-08bc-4891-9c73-dfbea31f2c44",
    "version": 'v1',
    "version_date": '2016-07-11'
});


// Replace with the context obtained from the initial request

exports.clear = function (req, next) {
    req.session.context = undefined;
    next();
};

exports.message = function(req, input, next){
    conversation.message({
        workspace_id: '40234538-7587-4bb8-9f23-fff5ec07c35f',
        input: {'text': input},
        context: req.session.context
    },  function(err, response) {
        //Importante para el contexto
        console.log(JSON.stringify(req.session.context,4))
        if (err)
            console.log('error:', err)
        else{
            req.session.context = response.context;//Recuperando el nuevo cotexto
            //console.log(JSON.stringify(response, null, 2));
            next(response);
        }
    });
};